Local Repo: ../my_localhost_git_origin (git remote set-url origin ../my_localhost_git_origin)
Remote Repo: https://github.com/neptunb/thk.git (git remote set-url origin https://github.com/neptunb/thk.git)

Copy and paste the folder "thk_examples"
Folder structure should be like as follows:

thk_examples
     |
     |-- my_localhost_git_origin      <-- this folder is used for git repository
     |-- README.txt
     |-- Screen
     |-- THKJS                        <-- this folder has code examples
            |- backend
            |- docker-compose.yml
            |- Dockerfile
            |- frontend


To Trace the Codes:
1. Install VS Code Application on your computer.
2. Open this folder (THKJS) on VS Code.
3. Be sure for extensions installed:
   - GitLens (GitKraken)
   - JavaScript and TypeScript Nightly (Microsoft)
4. Select a Git Tag from GitLens panel. It is shown in the "Screen" view.
5. Checkout a tag from list.
You should see the codes on script.js (Frontend) and app.js (Backend)

To Run the Codes:
1. Install  "Docker Desktop" on your computer.
2. Open a new terminal console at this folder (THKJS).
3. Run this command on the terminal: "docker compose up --build". Wait for building.
4. To test the running page, open a browser and write "http://localhost:8080" with live reload or http://localhost:3000 with manual refresing on url addresses, then press Enter key.
5. You should see the page. There is only a button or buttons due to selected code.
6. Press the button to test the codes.

To Stop Running Codes:
1. Shutdown the docker container, use this command "docker compose down".

https://github.com/neptunb/thk.git

